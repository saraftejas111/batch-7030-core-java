package com.person;

public class TestPerson {

	public static void main(String[] args) {

		Person p1 = new Person();

		//p1.age = 200;  // we can set invalid age
		//p1.name = "Raj Patil";
		
		p1.setAge(25);
		p1.setName("raj");

		p1.displayInfo();
	}
}
