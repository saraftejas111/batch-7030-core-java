package com.person;

public class Person {

	private int age;

	private String name;

	public void setAge(int age) {
		if (age < 110) {

			this.age = age;

		} else {
			System.out.println("invalid age");
		}
	}

	public void setName(String name) {
		if (name != null) {

			this.name = name;

		} else {
			System.out.println("invalid name");
		}
	}

	public void displayInfo() {
		System.out.println("--------------------------------");
		System.out.println("Name = " + name);
		System.out.println("Age = " + age);
		System.out.println("--------------------------------");
	}
}
