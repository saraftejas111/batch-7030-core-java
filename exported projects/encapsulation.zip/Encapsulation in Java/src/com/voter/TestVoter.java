package com.voter;

public class TestVoter {

	public static void main(String[] args) {

		Voter v1 = new Voter();
		v1.setAge(20);
		v1.setName("raj patil");

		System.out.println(v1);

		System.out.println("-------------------------------");

		v1.displayInfo();

	}
}
