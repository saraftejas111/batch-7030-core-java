package com.voter;

public class Voter {

	private int age;
	private String name;

	// public methods

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		if (age <= 110) {
			this.age = age;
		} else {
			System.out.println("invalid age");
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void displayInfo() {
		System.out.println("Name = "+name);
		System.out.println("Age = "+age);


	}

	@Override
	public String toString() {
		return "Name = " + name + "\nAge = " + age + "";
	}

}
