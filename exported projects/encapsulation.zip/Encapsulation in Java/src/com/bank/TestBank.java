package com.bank;

public class TestBank {

	public static void main(String[] args) {

		Account tejas = new Account();

		tejas.payment(200 , 12345) ;

		tejas.getBalance(1234);

	}
}
