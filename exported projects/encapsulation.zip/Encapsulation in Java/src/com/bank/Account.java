package com.bank;

public class Account {

	private int acc = 123456;
	private String name = "Tejas Saraf";
	private double balance = 1000;
	private int pin = 1234;

	public void payment(double amount, int pin) {

		if (this.pin == pin) {

			if (amount <= balance) {
				balance = balance - amount;
				System.out.println("payment done..");
				System.out.println("remaining balance = " + balance);

			} else {

				System.out.println("insufficient funds...");
			}
		} else {
			System.out.println("wrong pin");
		}
	}

	public void getBalance(int pin) {
		if (pin == this.pin) {
			System.out.println("Balance = " + this.balance);
		} else {
			System.out.println("wrong pin");
		}
	}

}
