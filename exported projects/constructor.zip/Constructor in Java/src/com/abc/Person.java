package com.abc;

public class Person {

	String name;
	int age;

	void displayPerson() { // method
		System.out.println("Name : " + name);
		System.out.println("Age : " + age);
	}

// here no constructor is created by developer,
// so compiler will provide default Constructor 

	public void Person() {
		System.out.println("hii i am default constructor later converted to method because of return type");

	}

// here we created constructor ,
// so compiler will not provide default or any Constructor 

	public Person(String n, int a) {
		System.out.println("hii i am parameterized constructor");
		name = n;
		age = a;
	}

	public Person(String n) {
		System.out.println("constructor overloading.. dev only providing name");
		name = n;
		age = 20;

	}

	public Person(int a) {
		System.out.println("constructor overloading.. dev only providing age");
		name = "no person name";
		age = a;

	}

	public Person() {
		System.out.println("constructor overloading.. dev is not providing name or age");
		name = "defualt name";
		age = 101010;
	}

}

/*
 * Contructor :
 * 
 * 1) It is a special type of block (not method) which is use to initialize the
 * objects.
 * 
 * 2) By using Constructor we can create Object of a class.
 * 
 * 3) Constructor name should be same as class name. (if changed, it is not
 * constructor)
 * 
 * 4) Constructor do not have any return type, not even void, if we try to
 * provide return type to Constructor , it will become a method
 * 
 * types : 1) default 2) parameterized
 * 
 * 5) if we do not add any constructor, compiler adds default counstructor
 * 
 * 6) but if we add any constructor , compiler will not going to add default or
 * any constructor
 * 
 * 7) 1 class can have multiple constructors by changing its parameters.
 * 
 * 8) Constructor in java can be Overload but not Override {polymorphism}
 * 
 * 9) why to create ? --> If we want to execute some logic or code at the time
 * of Object creation we can simply do it by using constructor.
 * 
 * 10) when object is created, constructor loads all the attributes (vars) &
 * methods of class and put into the object reff variable
 * 
 * 11) now we can call the variables & methods of the Demo class by using reff
 * varible
 * 
 * ex : dm.hello();
 * 
 * 12) if isntance variables are created but not assigned by any values
 * constructor provides default values to instance variables.
 * 
 * 13) constructor cannot be static. cannot be final 
 * 
 */