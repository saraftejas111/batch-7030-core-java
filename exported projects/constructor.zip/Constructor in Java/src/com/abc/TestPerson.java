package com.abc;

public class TestPerson {

	public static void main(String[] args) {

//		Person p1 = new Person(); //
//		p1.name = "Tejas";
//		p1.age = 30;
//		p1.displayPerson();

//      System.out.println("-------------------------------------------");		

//      Person p2 = new Person() ;
//		p2.displayPerson(); 

		// default values {provided by constructor}

//		System.out.println("-------------------------------------------");		

		Person p3 = new Person("kiran", 45);
		p3.displayPerson();
		
		System.out.println("-------------------------------------------");

		Person p4 = new Person("aman", 22);
		p4.displayPerson();
		System.out.println("-------------------------------------------");

		Person p5 = new Person("raj");
		p5.displayPerson();
		
		System.out.println("-------------------------------------------");

		Person p6 = new Person("sam");
		p6.displayPerson();
		
		
		System.out.println("-------------------------------------------");

		Person p7 = new Person(55);
		p7.displayPerson();
		
		
		System.out.println("-------------------------------------------");

		Person p8 = new Person(44);
		p8.displayPerson();
		
		
		
		System.out.println("-------------------------------------------");

		Person p9 = new Person();
		p9.displayPerson();
		
		
		
		
		
		
		
		
	}
}
